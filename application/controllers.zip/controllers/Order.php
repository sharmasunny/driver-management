<?php
defined('BASEPATH') OR exit('No direct script access allowed');
define('SHOPIFY_APP_SECRET', 'd5a002bbec4f13614c670de01b9caa7e');
/**
 * User class.
 * 
 * @extends CI_Controller
 */
class Driver extends CI_Controller {

	/**
	 * __construct function.
	 * 
	 * @access public
	 * @return void
	 */
	public function __construct() {
		parent::__construct();
		if (! $this->tank_auth->is_logged_in()) {
        	redirect('/');
    	}
		$this->load->library(array('session'));
		$this->load->helper(array('url'));
		$this->load->model('user_model');
		
	}
	
	
	public function index() {
		

	}


	public function order_Webhook(){
		$hmac_header = $_SERVER['HTTP_X_SHOPIFY_HMAC_SHA256'];
		$data = file_get_contents('php://input');
		$verified = $this->verify_webhook($data, $hmac_header);
	}
	

	function verify_webhook($data, $hmac_header)
	{
	  $calculated_hmac = base64_encode(hash_hmac('sha256', $data, SHOPIFY_APP_SECRET, true));
	  return ($hmac_header == $calculated_hmac);
	}






}